module.exports['missing-hyphens1.http'] = [
  {type: 'file', name: 'upload', filename: 'plain.txt', fixture: 'plain.txt',
  sha1: 'b31d07bac24ac32734de88b3687dddb10e976872'},
];
module.exports['missing-hyphens2.http'] = [
  {type: 'file', name: 'upload', filename: 'plain.txt', fixture: 'plain.txt',
  sha1: 'b31d07bac24ac32734de88b3687dddb10e976872'},
];
